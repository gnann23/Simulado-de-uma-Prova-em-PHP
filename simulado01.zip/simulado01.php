<?php

$nome = $_POST["nome"] ?? "";
$preco = $_POST["preco"] ?? 0;
$quantidade = $_POST["quantidade"] ?? 0;
$subtotal = $preco * $quantidade;

$produtos = [
    [
        'nome' => $nome,
        'preco' => $preco,
        'quantidade' => $quantidade,
        'subtotal' => $subtotal,
    ],
];

$totalEstoque = array_reduce($produtos, fn($total, $produto) => $total + $produto['subtotal'], 0);

function formatarMoeda(float $valor): string
{
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

$codigoRelatorio = rand(1000, 9999);
$data = date('d/m/Y H:i');

echo PHP_EOL . "==================================================" . PHP_EOL;
echo "            RELATÓRIO DE ESTOQUE                  " . PHP_EOL;
echo "==================================================" . PHP_EOL;
echo "Relatório Nº: {$codigoRelatorio} | Data: {$data}" . PHP_EOL;
echo "--------------------------------------------------" . PHP_EOL;

foreach ($produtos as $p) {
    echo "Item: {$p['nome']}" . PHP_EOL;
    echo "  Qtd: {$p['quantidade']} un | Preço Un: " . formatarMoeda($p['preco']) . PHP_EOL;
    echo "  Subtotal: " . formatarMoeda($p['subtotal']) . PHP_EOL;
    echo "--------------------------------------------------" . PHP_EOL;
}

echo "VALOR TOTAL EM ESTOQUE: " . formatarMoeda($totalEstoque) . PHP_EOL;
echo "==================================================" . PHP_EOL;