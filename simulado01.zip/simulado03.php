<?php

function verificarSituacao($media) {
    if ($media >= 7.0) {
        return "APROVADO";
    } elseif ($media >= 4.0) {
        return "RECUPERAÇÃO";
    } else {
        return "REPROVADO";
    }
}

echo "=== REGISTRO E ANÁLISE ACADÊMICA ===" . PHP_EOL;

$qtdAlunos = (int) readline("Informe o número de alunos: ");

while ($qtdAlunos <= 0) {
    echo "A quantidade de alunos deve ser maior que zero." . PHP_EOL;
    $qtdAlunos = (int) readline("Informe o número de alunos: ");
}

$turma = [];
$somaMedias = 0.0;

for ($i = 1; $i <= $qtdAlunos; $i++) {
    echo PHP_EOL . "--- Aluno {$i} ---" . PHP_EOL;
    $nome = readline("Nome do aluno: ");

    $n1 = (float) readline("Nota 1 (0 a 10): ");
    while ($n1 < 0 || $n1 > 10) {
        echo "Nota inválida! Digite entre 0 e 10." . PHP_EOL;
        $n1 = (float) readline("Nota 1 (0 a 10): ");
    }

    $n2 = (float) readline("Nota 2 (0 a 10): ");
    while ($n2 < 0 || $n2 > 10) {
        echo "Nota inválida! Digite entre 0 e 10." . PHP_EOL;
        $n2 = (float) readline("Nota 2 (0 a 10): ");
    }

    $media = ($n1 + $n2) / 2;
    $situacao = verificarSituacao($media);
    $somaMedias += $media;

    $turma[] = [
        'nome' => $nome,
        'nota1' => $n1,
        'nota2' => $n2,
        'media' => $media,
        'situacao' => $situacao
    ];
}

$mediaGeral = $qtdAlunos > 0 ? $somaMedias / $qtdAlunos : 0;

echo PHP_EOL . "===========================================================" . PHP_EOL;
echo "                  BOLETIM GERAL DA TURMA                  " . PHP_EOL;
echo "===========================================================" . PHP_EOL;

foreach ($turma as $aluno) {
    $mF = number_format($aluno['media'], 2, ',', '.');
    echo "Aluno: {$aluno['nome']} | Média: {$mF} | Situação: {$aluno['situacao']}" . PHP_EOL;
}

echo "----------------------------------------------------------" . PHP_EOL;
echo "MÉDIA GERAL DA TURMA: " . number_format($mediaGeral, 2, ',', '.') . PHP_EOL;
echo "===========================================================" . PHP_EOL;

echo "=== REGISTRO E ANÁLISE ACADÊMICA ===" . PHP_EOL;

$qtdAlunos = (int) readline("Informe o número de alunos: ");

while ($qtdAlunos <= 0) {
    echo "A quantidade de alunos deve ser maior que zero." . PHP_EOL;
    $qtdAlunos = (int) readline("Informe o número de alunos: ");
}

$turma = [];
$somaMedias = 0.0;

for ($i = 1; $i <= $qtdAlunos; $i++) {
    echo PHP_EOL . "--- Aluno {$i} ---" . PHP_EOL;
    $nome = readline("Nome do aluno: ");

    $n1 = (float) readline("Nota 1 (0 a 10): ");
    while ($n1 < 0 || $n1 > 10) {
        echo "Nota inválida! Digite entre 0 e 10." . PHP_EOL;
        $n1 = (float) readline("Nota 1 (0 a 10): ");
    }

    $n2 = (float) readline("Nota 2 (0 a 10): ");
    while ($n2 < 0 || $n2 > 10) {
        echo "Nota inválida! Digite entre 0 e 10." . PHP_EOL;
        $n2 = (float) readline("Nota 2 (0 a 10): ");
    }

    $media = ($n1 + $n2) / 2;
    $situacao = verificarSituacao($media);
    $somaMedias += $media;

    $turma[] = [
        'nome' => $nome,
        'nota1' => $n1,
        'nota2' => $n2,
        'media' => $media,
        'situacao' => $situacao
    ];
}

$mediaGeral = $qtdAlunos > 0 ? $somaMedias / $qtdAlunos : 0;

echo PHP_EOL . "==========================================================" . PHP_EOL;
echo "                  BOLETIM GERAL DA TURMA                  " . PHP_EOL;
echo "==========================================================" . PHP_EOL;

foreach ($turma as $aluno) {
    $mF = number_format($aluno['media'], 2, ',', '.');
    echo "Aluno: {$aluno['nome']} | Média: {$mF} | Situação: {$aluno['situacao']}" . PHP_EOL;
}

echo "----------------------------------------------------------" . PHP_EOL;
echo "MÉDIA GERAL DA TURMA: " . number_format($mediaGeral, 2, ',', '.') . PHP_EOL;
echo "==========================================================" . PHP_EOL;