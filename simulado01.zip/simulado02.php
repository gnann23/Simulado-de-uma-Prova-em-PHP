<?php

function calcularComissao(float $totalVendas): float {
    if ($totalVendas >= 20000.0) {
        return $totalVendas * 0.10; // 10%
    } elseif ($totalVendas >= 10000.0) {
        return $totalVendas * 0.07; // 7%
    } else {
        return $totalVendas * 0.05; // 5%
    }
}

function formatarMoeda(float $valor): string {
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

echo "=== SISTEMA DE VENDAS E COMISSÃO ===" . PHP_EOL;

$vendedor = readline("Nome do vendedor: ");
$vendas = [];

while (true) {
    $valorVenda = (float) readline("Informe o valor da venda (0 para encerrar): R$ ");

    if ($valorVenda === 0.0) {
        break;
    }

    if ($valorVenda < 0) {
        echo "Valor de venda inválido! Tente novamente." . PHP_EOL;
        continue;
    }

    $vendas[] = $valorVenda;
}

if (empty($vendas)) {
    echo PHP_EOL . "Nenhuma venda foi registrada para o vendedor {$vendedor}." . PHP_EOL;
} else {
    $totalVendas = 0.0;
    $maiorVenda = $vendas[0];

    foreach ($vendas as $venda) {
        $totalVendas += $venda;
        if ($venda > $maiorVenda) {
            $maiorVenda = $venda;
        }
    }

    $qtdVendas = count($vendas);
    $mediaVendas = $totalVendas / $qtdVendas;
    $comissao = calcularComissao($totalVendas);

    echo PHP_EOL . "==========================================" . PHP_EOL;
    echo "        RESUMO DE DESEMPENHO DO VENDEDOR   " . PHP_EOL;
    echo "==========================================" . PHP_EOL;
    echo "Vendedor         : {$vendedor}" . PHP_EOL;
    echo "Total de Vendas  : {$qtdVendas} venda(s)" . PHP_EOL;
    echo "Valor Total      : " . formatarMoeda($totalVendas) . PHP_EOL;
    echo "Média por Venda  : " . formatarMoeda($mediaVendas) . PHP_EOL;
    echo "Maior Venda      : " . formatarMoeda($maiorVenda) . PHP_EOL;
    echo "------------------------------------------" . PHP_EOL;
    echo "COMISSÃO A PAGAR : " . formatarMoeda($comissao) . PHP_EOL;
    echo "==========================================" . PHP_EOL;
}